//Deanna Tyner dtyner1@toromail.csudh.edu

import java.util.*;

import java.io.*;

public class DirectoryAnalyer {
	public static void main(String[] args) {
		
		
		String FileName = "C:\\test_files_java\\"; 
		
		
		File Direct = new File(FileName);
		
		FileInputStream in = null;
		
		try
		{
			if(!Direct.exists() || !Direct.isDirectory())
			{
				System.out.println("This directory dosen't exist, or it's not a directory");
			}
		
			
			int counter = 0;
			File [] File = Direct.listFiles();
			
			System.out.println("File Name:\t" + "Size:\t " + "Alpha characters:\t " + "Numbers:\t"  + "  Spaces:");
			
			long diskSize = 0;
			
			long UpperSize = 0;
			
			long NumSize = 0;
			
			long SpaceSize = 0;

			
			for(File f:File)
			{
				int Space = getAmountOfSpaces(f);
				
				int Numbers = AmountOfNumbers(f);
				
				int UpperCase = AmountOfUppercaseLetters(f);
				
				
				System.out.println(f.getName() + "\t" + (f.length() + " bytes")+ "\t\t" + UpperCase + "\t\t" + Numbers + "\t\t" + Space);
				
				diskSize = f.length() + diskSize;
				
				UpperSize += UpperCase;
				
				NumSize += Numbers;
				
				SpaceSize += Space;
				
				
			

			}
			
			
			System.out.println("\n");
			System.out.println("Toatl number of files: " + File.length);
			System.out.println("Total number of Alpha characters: " + UpperSize);
			System.out.println("Toatl number of Numeric characters: " + NumSize);
			System.out.println("Total number of Space characters: " + SpaceSize);
			
			
			
			
			System.out.println("Total disk size:" + diskSize + " bytes");
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
	}
	
	private static char readFile(File f) throws IOException {
		
		FileInputStream in = null;
		
		try
		{
			in = new FileInputStream(f);
			
			int How_Many = in.available();
			
			char t = 'o';
			
			for (int i = 0; i <= How_Many; i++)
			{
				t = (char)in.read();
				System.out.print(t);
			}
			
			return t;
		}

		finally
		{
			if(in != null)
			{
				in.close();
			}
		}
		
		
		
		
	}
	
	private static byte getBytes(File f) throws Exception{
		
		FileInputStream in = null;
		
		try
		{
			in = new FileInputStream(f);
			
			int How_Many = in.available();
			
			
			byte t = 0;
			
			byte o = 0;
			for (int i = 0; i <= How_Many; i++)
			{
				 t = (byte)in.read();
				 
				 o+=t;
				 
				//System.out.println(o);
			}
			
			return o;
			
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
		}

	}
	
	
	public static int getAmountOfSpaces(File f) throws Exception{
		
		FileInputStream in = null;
		
		try
		{
			in = new FileInputStream(f);
			
			int How_Many = in.available();
			
			
			byte t;
			int count = 0;
			for (int i = 0; i <= How_Many; i++)
			{
				 t = (byte)in.read();
				 
				 if(t == 32)
				 {
					count++;
				 }
				
			}
			
			return count;

			
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
		}
		
		
	}
	
 public static int AmountOfUppercaseLetters(File f) throws Exception{
		
		FileInputStream in = null;
		
		try
		{
			in = new FileInputStream(f);
			
			int How_Many = in.available();
			
			
			char t;
			
			int count = 0;
			
			for (int i = 0; i <= How_Many; i++)
			{
				 t = (char)in.read();
				 
				 if(Character.isUpperCase(t))
				 {
					 count++;
				 }
				 
				
			}
			return count;
			
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
		}
		
		
	}
 public static int AmountOfNumbers(File f) throws Exception{
		
		FileInputStream in = null;
		
		try
		{
			in = new FileInputStream(f);
			
			int How_Many = in.available();
			
			
			char t;
			
			int count = 0;
			for (int i = 0; i <= How_Many; i++)
			{
				 t = (char)in.read();
				 
				 if(Character.isDigit(t))
				 {
					count++; 
				 }
	
			}
			return count;
			
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
		}
		
		
	}
 
 
}
