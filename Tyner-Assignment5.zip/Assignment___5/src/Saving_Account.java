public class Saving_Account extends Account{

	
	
	public Saving_Account(int Account_Number, String Account_Type, Customer Account_Holder) {
		super(Account_Number, Account_Type, Account_Holder);
	}
	
	
	public double withdraw(double amount) {
		
		if(getBalance() - amount < 0)
		{
			return getBalance();
		}
		else
		{
			super.withdraw(amount);
			
			return getBalance();
		}
		
		
	}
	
	public double deposit(double amount) {

		
		if(amount < 0 || isOpen() == false)
		{
			return getBalance();
		}
		else
		{
			super.deposit(amount);
			return getBalance();
		}
				
		
		
	}
	
	public boolean equals(Object AH) {
		
		if(!(AH instanceof Saving_Account)) {
			return false;
		}
		else
		{
			Saving_Account save = (Saving_Account) AH ;
			
			return (super.equals(save));
		}
	


	}
}
