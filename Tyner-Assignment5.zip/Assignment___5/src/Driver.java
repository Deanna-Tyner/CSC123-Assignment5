// Deanna Tyner (dtyner1@toromail.csudh.edu)

import java.util.*;

import java.io.*;

public class Driver {
	
	public static void main(String[] args) throws NoSuchAccountException{//Any attempt to use 2 or 1 again causes the "Enter first name" line to skip
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("1 -  Open a Checking account\n2 –  Open Saving Account\n3 –  List Accounts\n4 -  Account Statement"
							+ "\n5 -  Deposit funds\n6 -  Withdraw funds\n7 -  Close an account\n8 -  Save Transactions"
							+ "\n9 -  Close System");
		
		int option;
		
		System.out.println("Please select one of the options above: ");
		option = input.nextInt();
		String dummyline = input.nextLine();
		
		ArrayList<Customer> I = new ArrayList<Customer>();
		
		while (option <= 9 || option >= 1) {
			
			String FName = null;
			
			String LName = null;
			
			String email = null;
			
			String ssn = null;
			
			String Type = null;
			
			int acc_Num = 999;
			
			int limit = 0;
			
			
			
			
			if(option == 1) {
				
				System.out.println("Please enter your first name: ");
				FName = input.nextLine();
		
				System.out.println("Please enter your last name: ");
				LName = input.nextLine();
		
				System.out.println("Please enter your email: ");
				email = input.nextLine();
		
				System.out.println("Please enter your social security number: ");
				ssn = input.nextLine();
				
				System.out.println("Please enter your overdraft limit: ");
				limit = input.nextInt();
				
				Type = "Checking";
				
				acc_Num += 1;
				
				Bank.OpenAccount(FName, LName, email, ssn, Type);
				
				System.out.println("Thank you, the account number is " + (Bank.Account_Number ));
			}
			
			if (option == 2) {
				
				System.out.println("Please enter your first name: ");
				FName = input.nextLine();
		
				System.out.println("Please enter your last name: ");
				LName = input.nextLine();
		
				System.out.println("Please enter your email: ");
				email = input.nextLine();
		
				System.out.println("Please enter your social security number: ");
				ssn = input.nextLine();
				
				Type = "Saving";
				
				acc_Num += 1;
				
				Bank.OpenAccount(FName, LName, email, ssn, Type);
				
				System.out.println("Thank you, the account number is " + (Bank.Account_Number ));//The number doesn't go up, try something else?
		
				
			}
			
			else if (option == 3) {
				
			
					Bank.PrintAccounts();

				
			}
			
			else if (option == 4) {
				
				int AccNum;
				System.out.println("Please enter your account number: ");
				AccNum = input.nextInt();
				try
				{
					
					
					Account a=Bank.FindAccount(AccNum);
					if(a != null)
					{
						Bank.printTransactions(AccNum);
					}
					if(a == null)
					{
						throw new NoSuchAccountException("No such account exists"); 
					}
					/*else
					{
						System.out.println("No such account exists");
					}*/
					
				}
				catch(NoSuchAccountException no)
				{
					System.out.println("No such account exists" );
					//System.out.println(no.getMessage());
				}
				
			}
			
			else if (option == 5) {//I don't even know where to start with the transactions, need help
				
				int AccNum;
				
				double amount;
				
				System.out.println("Please enter your account number: ");
				AccNum = input.nextInt();
				
				System.out.println("Please enter the amount you want to deposit: ");
				amount = input.nextDouble();
			
			
				Account a = Bank.FindAccount(AccNum);
				
				try
				{
					if(a != null && a.isOpen())
					{
					a.deposit(amount);
					System.out.println("Deposit succesful" ); 
					Bank.printBalance(AccNum);
					}
					
					if(a == null || !a.isOpen())
					{
						throw new NoSuchAccountException("No such account exists"); 
					}
					
					if(!a.isOpen())
					{
						throw new AccountClosedException("Account Closed");
					}
					
				}
				catch(NoSuchAccountException no)
				{
					System.out.println("No such account exists" );
				}
				catch(AccountClosedException clo)
				{
					System.out.println("Account closed");
				}
				
				
				
				
			}
			
			else if (option == 6) {
				
				int AccNum;
				
				double amount;
				
				
				
				
				System.out.println("Please enter your account number: ");
				AccNum = input.nextInt();
				
				System.out.println("Please enter the amount you want to withdraw: ");
				amount = input.nextDouble();
				
				Account a=Bank.FindAccount(AccNum);
				
				try
				{
					if(a != null && a.isOpen())
					{
						a.withdraw(amount);
						System.out.println("Withdraw succesful");
						Bank.printBalance(AccNum);
					}
					
					if(a == null)
					{
					throw new NoSuchAccountException("No such account exists");
					}
					
					if(!a.isOpen())
					{
						throw new AccountClosedException("Account Closed");
					}
					
				}
				catch(NoSuchAccountException no)
				{
					System.out.println("No such account exists");
				}
				catch(AccountClosedException clo)
				{
					System.out.println("Account closed");
				}
				
			
				
	
			}
			
			else if (option == 7) {
				
				int AccNum;
				
				System.out.println("Please enter your account number: ");
				AccNum = input.nextInt();
				
				Account a = Bank.FindAccount(AccNum);
				
				try
				{
					if(a != null)
					{
						System.out.println(Bank.ClosedOrOpen(AccNum));
					}
					if(a == null)
					{
						throw new NoSuchAccountException("No such account exists");
					}
				}
				catch(NoSuchAccountException no)
				{
					System.out.println("No such account exists");
				}
				
								
				
			}
			
			else if(option == 8) {
				
				
				
				PrintWriter writer = null;
				
				int AccNum;
				
				System.out.println("Please enter your account number: ");
				AccNum = input.nextInt();
				
				Account a=Bank.FindAccount(AccNum);
				
				//Bank.printBalance(AccNum); 
				
				//void t = Bank.printTransactions(AccNum);
				
				if(a == null || !a.isOpen())
				{
					System.out.println("Account not found or is closed");
				}
				else
				{
					File Trans_File = new File("C:\\test_files_java\\transactions.txt");
					
					
					try
					{
						Trans_File.createNewFile();
						
						writer = new PrintWriter(Trans_File);
						
						Bank.printTransactions(AccNum, writer); //why does it want to be a boolean???? Find out how to print the transactions

						
					}
					catch(Exception e)
					{
						System.out.println(e.getMessage());
					}
					finally
					{
						if(writer != null)
						{
							writer.flush();
							writer.close();
						}
					}
				}
				
				
				
				
			}
			
			else if(option == 9) {
				System.out.println("Thank you for using this bank, goodbye");
				System.exit(0);
			}
			
			
			
			
			System.out.println("1 -  Open a Checking account\n2 –  Open Saving Account\n3 –  List Accounts\n4 -  Account Statement"
					+ "\n5 -  Deposit funds\n6 -  Withdraw funds\n7 -  Close an account\n8 -  Save Transactions"
					+ "\n9 -  Close System");
			
			System.out.println("Please select on of the options above:");
			option = input.nextInt();
			String dummyline2 = input.nextLine();
			
		}
		
	}

}
