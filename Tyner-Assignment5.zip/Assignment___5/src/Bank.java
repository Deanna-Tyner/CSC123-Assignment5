// Deanna Tyner (dtyner1@toromail.csudh.edu)


// The reason as to why I chose a HashMap instead of a TreeMap is
// that it would only be more visually pleasing 

import java.util.*;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.*;

public class Bank {//Is the Bank connected to Transactions, or is Accounts connected to Transactions?
	
	
	protected static int Account_Number = 1000;
	protected static Map <Integer, Account> accountss = new HashMap<Integer,Account>();
	
	private Bank() {}
	
	public static Account OpenAccount(String First_Name, String Last_Name, String Email, String SSN, String type) {
		
		Customer customer = new Customer (First_Name, Last_Name, Email, SSN);
		
		Account account = new Account(Account_Number++, type, customer);
		
		accountss.put(Account_Number, account);
		
		return account;
		
	}
	

	
	public static int getAccountNumber() {
		return Account_Number;
	}
	
	public static Account FindAccount(int AccountNumber) {
		
		
			return accountss.get(AccountNumber++); 
			
		
	}
	

	
	public static String ClosedOrOpen(int Account_Number) {
		
		
		
		if (closeAccount(Account_Number) == true)
		{
			return "The account is closed";
		}
		else
		{
			return "This account doen't exist";
		}
		
		
	}
	
	
	
	public static boolean closeAccount(int AccountNumber) {
		boolean flag = false;
		
		if(FindAccount(AccountNumber)!=null){
			FindAccount(AccountNumber).closeAccount();
			flag = true;
		}
		
		return flag;
		
		
		
		
		
	}
	
	
	
	public static void PrintAccounts() {
		
		for(Integer LOL: accountss.keySet())
		{
			String key = LOL.toString();
			String value = accountss.get(LOL).toString();
			System.out.println(value);
		}
		
	}
	public static void printTransactions(int AccNum) {
		
		Account tempAcc = FindAccount(AccNum);
		tempAcc.printStatement();
		
	}
	

	public static void printTransactions(int AccNum,PrintWriter pw) {
		
		Account tempAcc = FindAccount(AccNum);
		tempAcc.printStatement( pw);
		
	}

	public static void printBalance(int AccNum)
	{
		Account balc = FindAccount(AccNum);
		balc.PrintBalance();
	}
	
	
		
	}
	
