// Deanna Tyner (dtyner1@toromail.csudh.edu)

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;

public class Account {
	
	private int Account_Number;
	
	protected String Account_Type;
	
	private boolean Account_Open;
	
	private double Balance;
	
	protected double Money = 0.0;
	
	private Customer Account_Holder;
	
	protected String Trans_Type;
	
	
	
	protected ArrayList <Transaction> trxns = new ArrayList<Transaction>();
	
	
	public Account(int Account_Number, String Account_Type, Customer Account_Holder) {
		
		this.Account_Number = Account_Number;
		
		this.Account_Type = Account_Type;
		
		this.Account_Holder = Account_Holder;
		
		Account_Open = true;
		
	}
	
	
	
	public double getMoney() {
		return Money;
	}
	
	public void setMoney(double Money) {
		this.Money = Money;
	}
	
	
	public void printStatement() {
		

		
		for(Transaction a: trxns)
		{
			int t = 200;
			System.out.println((t++) + ":" + a.getTypeOfAccount() + ":" + a.getAmount());
		}
		
		
		System.out.println(getBalance());
	}
	
	public void printStatement(PrintWriter pw) {
		

		
		for(Transaction a: trxns)
		{
			int t = 200;
			String line=(t++) + ":" + a.getTypeOfAccount() + ":" + a.getAmount();
			pw.write(line);
		}
		
		
	
		
		pw.write(getBalance()+"");
	}
	
	public double PrintBalance() {
		return getBalance();
		
	}

	public void printBalance() {
		
		System.out.println(getBalance());
		
	}
	
	
	
	
	public String ShowDeposit(double amount, String type,int Account_Number) {
		
		Account a = Bank.FindAccount(Account_Number);
		
		if (a.deposit(amount) == 0)
		{
			return "Deposit unsuccesful";
		}
		else
		{
			return "Deposit succesful, you currently have " + getBalance();
		}
	}
	
	public String ShowWithdraw(double amount, String type,int Account_Number) {
		
		Account a = Bank.FindAccount(Account_Number);
		
		if(a.withdraw(amount) < 0 || isOpen() == false)
		{
			return "Withdraw unsuccesful";
		}
		else 
		{
			return "Withdraw succesful, you currently have " + getBalance();
		}
		
	}
	
	public double withdraw(double amount) {
		
		
		Transaction tn = new Transaction(amount, "Debit" , this.Account_Number);
		trxns.add(tn);

		
		return getBalance();
		
	
		
	}
	
	public double deposit(double amount) {
		
		
		Transaction ta = new Transaction(amount, "Credit", this.Account_Number);
			
		trxns.add(ta);
		
		return getBalance();
		
	
	}
	
	
	
	public Transaction Man(String type, double amount, int Account_Number) {
		
		Transaction trans = new Transaction(amount, " " , this.Account_Number);
		
		trxns.add(trans);
		
		return trans;
		
		
	}
	
	public boolean isOpen() {
		
		return this.Account_Open;
	}
	
	public void closeAccount() {
		this.Account_Open = false;
	}
	
	public String OpenOrClosed () {
		
		String Account_Status = "";
		
		if (isOpen() == true)
		{
			Account_Status = "Account Open";
		}
		else if(isOpen() == false)
		{
			Account_Status = "Account Closed";
		}
		
		return Account_Status;
	}
	
	public double getBalance() {

		double deposits = 0;
		double withdraws = 0;
		
		for(Transaction tb: trxns)
		{
			
			if(tb.getTypeOfAccount().equalsIgnoreCase("Credit"))
			{
				deposits += tb.getAmount();

				
			}
			
			
			else if (tb.getTypeOfAccount().equalsIgnoreCase("Debit"))
			{
				withdraws += tb.getAmount();
			}
			
		}
		
		return deposits - withdraws;
	}
	
	public String getAccountType() {
		return Account_Type;
	}
	
	public int getAccountNumber() {
		return Account_Number;
	}
	
	public void AccountType(String Account_Type) {
		
		this.Account_Type = Account_Type;
		
	}
	
	
	
	public String toString() {
		
		return (this.Account_Number + 1) + " : " + Account_Type + " : " + this.Account_Holder.toString()+ " : " + getBalance() + " : " + OpenOrClosed();
		
	}
	

}
