//Deanna Tyner dtyner1@toromail.csudh.edu

import java.io.*;

import java.util.*;

public class FileCopy {
	public static void main(String[] args) throws MyException{
		
		File Source_File = new File("C:\\test_files_java\\Text.txt");
		
		File Target_File = new File(Source_File.getParent(),"Target.txt");
		
		String string = "Hello World. How are you today?";
		
		
		
		
		
		FileOutputStream output = null;
		FileInputStream in = null;
		
		try
		{
			
			Source_File.createNewFile();
			
			if(!Source_File.exists())
			{
				throw new MyException("File doesn't exist");
			}
			
			if(!Target_File.exists())
			{
				Target_File.createNewFile();
			}
			else
			{
				throw new Exception("This file already exists");
			}
			
			if(Source_File.isDirectory()|| Target_File.isDirectory())//How to check if the files are directories
			{
				throw new MyException("This program works with files only");	
			}
			
			
			
			
			
			output = new FileOutputStream(Source_File);
			
			byte[] bytes = string.getBytes();
			
			for(byte b: bytes)
			{
				output.write(b);
			}
			output.flush();
			
			
			
			in = new FileInputStream(Source_File);
	
			
			int How_Many = in.available();
			
			FileOutputStream  output2 = new FileOutputStream(Target_File);
		
			for(int i = 0; i<= How_Many; i++)
			{
				byte t = (byte)in.read();
				
				output2.write(t);
			}
			
			output2.flush();
			
			System.out.println(How_Many + " worth of bytes copied from " + Source_File.getName() + " to " + Target_File.getName());
		
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		finally
		{
			if(output != null)
			{
				try {
				output.close();
				}
				catch(IOException ignore) {}
			}
		}
		
		
		
		
	}

}
