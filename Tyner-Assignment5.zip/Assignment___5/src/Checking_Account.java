public class Checking_Account extends Account{
	
	public double Deposit;
	
	private int Limit;
	
	public Checking_Account(int Account_Number, String Account_Type, Customer Account_Holder, int Limit) {
		super(Account_Number, Account_Type, Account_Holder);
		

		setLimit(Limit);
		
	}
	
	
	public int getLimit() {
		
		return Limit;
		
	}
	
	public void setLimit(int Limit) {
		
		this.Limit = Limit;
		
	}
	
	public double withdraw(double amount, int Limit) {
			
		
		this.Limit = Limit;
		
		if(getBalance() - amount < -(Limit))
		{
			return getBalance();
		}
		else
		{
			super.withdraw(amount);
			
			return getBalance();
		}
		
	}
	
	public double deposit(double amount) {

		
		if(amount < 0 || isOpen() == false)
		{
			return getBalance();
		}
		else
		{
			super.deposit(amount);
			return getBalance();
		}
		
	}	
	
	public boolean equals(Object AH) {
		
		if(!(AH instanceof Checking_Account)) {
			return false;
		}
		else
		{
			Checking_Account chk = (Checking_Account) AH ;
			
			return (super.equals(chk));
		}
		
	}
	
	

}
