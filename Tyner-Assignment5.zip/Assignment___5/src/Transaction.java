import java.util.ArrayList;

import java.util.*;

// Deanna Tyner (dtyner1@toromail.csudh.edu)

public class Transaction {//Find a way on how to connect Transactions to Checking_Account and Saving_Account,
						  // will making an array list help me go through everything? 
						  //Or should I take the accounts object from the Bank class?
						  //Will the Credit and Debit transactions even be necessary?
	
	
	private double Credit_Transaction;
	
	private double Debit_Transactions;
	
	protected double amount;
	
	private int Trans_ID = 200;
	
	private String type; //"C"/"D" //I need to somehow find a way on how to get the Account_Type from account
		
	public Transaction(double amount, String type, int account_Number) {
		
		
		this.amount = amount;
		
		this.type = type;
		
	}
	
	public double getAmount() {
		return amount;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public String getTypeOfAccount() {
		
		return type;
		
	}
	
	public void setTypeOfAccount(String type) {
		this.type = type;
	}
	
	

}

