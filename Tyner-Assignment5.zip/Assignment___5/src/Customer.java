// Deanna Tyner (dtyner1@toromail.csudh.edu)

public class Customer {
	
	private String First_Name;
	
	private String Last_Name;
	
	private String Email;
	
	private String SSN;
	
	
	public Customer (String First_Name, String Last_Name, String Email, String SSN) {
		
		this.First_Name = First_Name;
		
		this.Last_Name = Last_Name;
		
		this.Email = Email;
		
		this.SSN = SSN;
		
	}
	
	public String getFirstName() {
		return First_Name;
	}
	
	public void setFirstName(String First_Name) {
		
		this.First_Name = First_Name;
		
	}
	
	public String getLastName(){
		return Last_Name;
	}
	
	public void setLastName(String Last_Name) {
		
		this.Last_Name = Last_Name;
		
	}
	
	public String getEmail() {
		return Email;
	}
	
	public void setEmail(String Email) {
		
		this.Email = Email;
		
	}
	
	public String getSSN() {
		return SSN;
	}
	
	public void setSSN(String SSN) {
		
		this.SSN = SSN;
		
	}
	
	
	public String toString() {
		
		return First_Name + " : " + Last_Name + " : "  + SSN ;
		
	}

}
